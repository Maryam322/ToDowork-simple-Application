# To-Do List Application

A simple and interactive To-Do List application built with vanilla JavaScript, HTML, and CSS. This application allows users to manage their daily tasks efficiently.

## Features

- **Add Task**: easily add new tasks to your list.
- **Remove Task**: Delete tasks that are no longer needed.
- **Update Task**: Edit the text of existing tasks.
- **Reorder Tasks**: Move tasks up or down to prioritize them.
- **Task Selection**: Click on a task to select it for editing or removal.
- **Timestamps**: Each task displays the date and time it was added.

## How to Run

1.  Clone or download this repository.
2.  Open the `index.html` file in any modern web browser.

## Technologies Used

- **HTML5**: For the structure of the application.
- **CSS3**: For styling and layout.
- **JavaScript**: For logic and interactivity (DOM manipulation).

## Project Structure

- `index.html`: The main HTML file.
- `style.css`: Contains all the styles for the application.
- `script.js`: Contains the JavaScript logic for task management.
