// Get DOM elements
const taskInput = document.getElementById('taskInput');
const addTaskButton = document.getElementById('addTaskButton');
const removeTaskButton = document.getElementById('removeTaskButton');
const updateTaskButton = document.getElementById('updateTaskButton');
const taskTableBody = document.getElementById('taskTableBody');

// Array to store tasks
let tasks = [];
let selectedTaskId = null;

// Add Task
addTaskButton.addEventListener('click', function() {
    const taskText = taskInput.value.trim();
    
    if (taskText === '') {
        alert('Please enter a task');
        return;
    }
    
    // Create task object
    const task = {
        id: Date.now(),
        text: taskText,
        date: new Date().toLocaleDateString(),
        time: new Date().toLocaleTimeString(),
        completed: false
    };
    
    // Add to tasks array
    tasks.push(task);
    
    // Clear input
    taskInput.value = '';
    
    // Render tasks
    renderTasks();
});

// Remove Task
removeTaskButton.addEventListener('click', function() {
    if (selectedTaskId === null) {
        alert('Please select a task to remove');
        return;
    }
    
    // Remove task from array
    tasks = tasks.filter(task => task.id !== selectedTaskId);
    selectedTaskId = null;
    
    // Render tasks
    renderTasks();
});

// Update Task
updateTaskButton.addEventListener('click', function() {
    const taskText = taskInput.value.trim();
    
    if (selectedTaskId === null) {
        alert('Please select a task to update');
        return;
    }
    
    if (taskText === '') {
        alert('Please enter task text');
        return;
    }
    
    // Update task
    const task = tasks.find(t => t.id === selectedTaskId);
    if (task) {
        task.text = taskText;
        taskInput.value = '';
        renderTasks();
    }
});

// Render Tasks in Table
function renderTasks() {
    taskTableBody.innerHTML = '';
    
    tasks.forEach((task, index) => {
        const row = document.createElement('tr');
        row.id = `task-${task.id}`;
        
        // Highlight selected row
        if (task.id === selectedTaskId) {
            row.style.backgroundColor = '#e3f2fd';
        }
        
        row.innerHTML = `
            <td>${index + 1}</td>
            <td>${task.text}</td>
            <td>${task.date} ${task.time}</td>
            <td>
                <button class="btn edit" data-id="${task.id}">Edit</button>
                <button class="btn delete" data-id="${task.id}">Del</button><br>
                <button class="btn up" data-id="${task.id}">Up</button>
                <button class="btn down" data-id="${task.id}">Down</button>
            </td>
        `;
        
        // Row click to select
        row.addEventListener('click', function() {
            selectedTaskId = task.id;
            taskInput.value = task.text;
            renderTasks();
        });
        
        taskTableBody.appendChild(row);
    });
    
    attachButtonListeners();
}

// Attach event listeners to action buttons
function attachButtonListeners() {
    // Edit buttons
    document.querySelectorAll('.btn.edit').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = parseInt(this.getAttribute('data-id'));
            selectedTaskId = id;
            const task = tasks.find(t => t.id === id);
            if (task) {
                taskInput.value = task.text;
            }
            renderTasks();
        });
    });
    
    // Delete buttons
    document.querySelectorAll('.btn.delete').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = parseInt(this.getAttribute('data-id'));
            tasks = tasks.filter(task => task.id !== id);
            selectedTaskId = null;
            renderTasks();
        });
    });
    
    // Up buttons (Move task up)
    document.querySelectorAll('.btn.up').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = parseInt(this.getAttribute('data-id'));
            const index = tasks.findIndex(t => t.id === id);
            if (index > 0) {
                [tasks[index], tasks[index - 1]] = [tasks[index - 1], tasks[index]];
                renderTasks();
            }
        });
    });
    
    // Down buttons (Move task down)
    document.querySelectorAll('.btn.down').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const id = parseInt(this.getAttribute('data-id'));
            const index = tasks.findIndex(t => t.id === id);
            if (index < tasks.length - 1) {
                [tasks[index], tasks[index + 1]] = [tasks[index + 1], tasks[index]];
                renderTasks();
            }
        });
    });
}

// Allow Enter key to add task
taskInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        addTaskButton.click();
    }
});
